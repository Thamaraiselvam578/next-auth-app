export default async function Layout({ children, }: { children: React.ReactNode }) {
    return (
        <div className="min-h-lvh overflow-y-auto p-5 box-border">{children}</div>
    );
}
