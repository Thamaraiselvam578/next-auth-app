import { Box, Typography } from '@mui/material'
import React from 'react'

const About = () => {
    return (
        <Box sx={{ p: 3 }}>
            <Typography variant="h4" sx={{ mt: 2 }}>About Me</Typography>
            <Typography variant="body1" sx={{ mt: 1, opacity: .7 }}>I,m a us at: Lorem ipsum, dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsam sequi magni illum necessitatibus vero perferendis doloremque mollitia aspernatur praesentium corrupti pariatur tenetur laudantium culpa optio voluptatem perspiciatis, neque fugit non eligendi eius! Quibusdam ad velit, voluptatibus ab similique sint officia, dolore consequatur libero non repellat molestiae nemo beatae error. consectetur adipisicing elit. Facere quisquam quibusdam dolore cumque quae consequatur et aspernatur recusandae enim quam corporis ab reiciendis perspiciatis hic unde, maiores quasi magni fugiat.</Typography>
            <Typography variant="body1" sx={{ mt: 4, opacity: .7 }}>Dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsam sequi magni illum necessitatibus vero perferendis doloremque mollitia aspernatur praesentium corrupti pariatur tenetur laudantium culpa optio voluptatem perspiciatis, neque fugit non eligendi eius! Quibusdam ad velit, voluptatibus ab similique sint officia, dolore consequatur libero non repellat molestiae nemo beatae error. consectetur adipisicing elit. Facere quisquam quibusdam dolore cumque quae consequatur et aspernatur recusandae enim quam corporis ab reiciendis perspiciatis hic unde, maiores quasi magni fugiat.</Typography>
            <Typography variant="body1" sx={{ mt: 4, opacity: .7 }}>Sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates ipsam sequi magni illum necessitatibus vero perferendis doloremque mollitia aspernatur praesentium corrupti pariatur tenetur laudantium culpa optio voluptatem perspiciatis, neque fugit non eligendi eius! Quibusdam ad velit, voluptatibus ab similique sint officia, dolore consequatur libero non repellat molestiae nemo beatae error. consectetur adipisicing elit. Facere quisquam quibusdam dolore cumque quae consequatur et aspernatur recusandae enim quam corporis ab reiciendis perspiciatis hic unde, maiores quasi magni fugiat.</Typography>
        </Box>
    )
}

export default About