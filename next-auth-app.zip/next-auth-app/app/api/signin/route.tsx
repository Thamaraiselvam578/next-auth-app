import { signIn } from '@/auth'
import type { NextApiRequest, NextApiResponse } from 'next'
import { AuthError } from 'next-auth'

type ResponseData = {
    message: string
}

export default async function POST(req: NextApiRequest, res: NextApiResponse<ResponseData>) {
    try {
        const { email, password } = req.body
        await signIn("credentials", { email, password })
        res.status(200).json({ message: "Login Successfull" })

    } catch (error) {
        if (error instanceof AuthError) {
            return { message: error.cause?.err?.message, status: "error" }
        }
        res.status(500).json({ message: 'Something went wrong!' })
    }
}